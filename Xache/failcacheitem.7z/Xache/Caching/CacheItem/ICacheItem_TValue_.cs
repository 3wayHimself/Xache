﻿namespace Xache.Caching
{
	public interface ICacheItem<TValue> : ICacheItem
	{
		new TValue Value { get; }
	}
}
