﻿using System;

namespace Xache.Caching
{
	public interface ICacheItem
	{
		object Value { get; }

		void FreeResources();
		bool HasValue { get; }
		bool InUse { get; }
		void SetValue<T>(Func<T> getValue);

		void MarkInUse();
		void MarkOutOfUse();
	}
}
