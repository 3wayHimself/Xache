﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Xache.Caching
{

	public class CacheItem<TValue> : ICacheItem<TValue>
	{
		public CacheItem(TValue value, ICachingMethod<TValue> top)
		{
			Value = value;
			_method = top;
		}

		private readonly ICachingMethod<TValue> _method;

		public TValue Value { get; private set; }

		public bool HasValue => Value == default;

		object ICacheItem.Value => Value;

		private int useAmt;
		public bool InUse => useAmt > 0;
		private object _lock = new object();
		private ManualResetEventSlim _mre = new ManualResetEventSlim(false);

		public void FreeResources()
		{
			var skipWait = false;

			lock(_lock)
			{
				if (useAmt == 0) skipWait = true;
				_mre.Reset();
			}

			if(!skipWait) _mre.Wait();

			if (Value is IDisposable dispose)
				dispose.Dispose();

			Value = default;
		}

		public void MarkInUse()
		{
			lock (_lock)
			{
				useAmt++;

				_mre.Reset();
			}
		}

		public void MarkOutOfUse()
		{
			lock (_lock)
			{
				useAmt--;

				if (useAmt < 1) _mre.Set();
			}
		}

		public void SetValue<T>(Func<T> getValue)
		{
			var result = getValue();

			if (result is TValue tvalueRes)
				Value = tvalueRes;
		}
	}
}
