﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace Xache.Tests
{
	public class CacheItem
	{
		[Fact]
		public void MarksInUse()
		{

		}
	}
}
